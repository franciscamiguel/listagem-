/// <summary>
/// Calcula a soma de dois números inteiros.
/// </summary>
/// <param name="a">O primeiro número inteiro.</param>
/// <param name="b">O segundo número inteiro.</param>
/// <returns>A soma dos dois números.</returns>
public int Soma(int a, int b)
{
    return a + b;
}
